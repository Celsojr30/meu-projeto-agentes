import os
from crewai_tools import SerperDevTool
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM

load_dotenv()

#print("Sua chave é:", os.getenv("GOOGLE_API_KEY"))

# Configura o LLM usando o wrapper oficial do CrewAI com os parâmetros corretos
gemini_llm = LLM(
    model="gemini/gemini-2.5-flash",    # Prefixo oficial para o provedor interno
    api_key=os.getenv("GEMINI_API_KEY"), # Passa a chave explicitamente para evitar falhas
    temperature=0.5
)

# Inicializar a ferramenta de busca
# Ela vai ler automaticamente a variável SERPER_API_KEY do seu ambiente
ferramenta_busca = SerperDevTool()

# Definir os Agentes
pesquisador = Agent(
    role="Pesquisador Sênior de Tecnologia",
    goal="Buscar e sintetizar as principais tendências e novidades sobre o tema fornecido.",
    backstory="""Você é um pesquisador obstinado que encontra os insights mais profundos. 
    Sua especialidade é filtrar o barulho da internet e focar no que realmente importa 
    e traz valor prático para profissionais da área.""",
    verbose=True,
    allow_delegation=False,
    tools=[ferramenta_busca],
    llm=gemini_llm
)

escritor = Agent(
    role="Redator Técnico e Especialista em Engajamento",
    goal="Transformar relatórios técnicos em posts atraentes, claros e acionáveis para o LinkedIn.",
    backstory="""Você é um copywriter de tecnologia renomado. Você consegue transformar 
    assuntos complexos em textos simples, engajadores e com excelente formatação (bullet points, ganchos atraentes).""",
    verbose=True,
    allow_delegation=False,
    llm=gemini_llm
)

# Definir as Tarefas
tema_projeto = "Tendências de Hiperautomação e IA no mercado de TI em 2026"

tarefa_pesquisa = Task(
    description=f"Pesquise e levante os 3 pontos mais cruciais sobre o tema: '{tema_projeto}'. Foque em impactos práticos e mercado.",
    expected_output="Um relatório em tópicos com as 3 principais tendências e uma breve explicação de cada.",
    agent=pesquisador
)

tarefa_escrita = Task(
    description="Com base no relatório gerado pelo pesquisador, crie um post formatado para o LinkedIn.",
    expected_output="Um post de LinkedIn engajador, com título chamativo, uso de bullet points, conclusões e hashtags relevantes.",
    agent=escritor
)

# Orquestrar o Crew (A Equipe)
equipe_automacao = Crew(
    agents=[pesquisador, escritor],
    tasks=[tarefa_pesquisa, tarefa_escrita],
    process=Process.sequential, # A tarefa de escrita acontece DEPOIS da pesquisa
    verbose=True
)

# Iniciar o trabalho
print("## Iniciando o processo dos agentes de IA... ##")
resultado_final = equipe_automacao.kickoff()

print("\n\n########################")
print("## RESULTADO DO POST GERADO ##")
print("########################\n")
print(resultado_final)